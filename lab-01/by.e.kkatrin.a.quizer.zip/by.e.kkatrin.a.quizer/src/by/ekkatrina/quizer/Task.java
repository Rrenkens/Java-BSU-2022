package by.ekkatrina.quizer;

public interface Task {
    String getText();

    Result validate(String answer);
    boolean isNumber(String answer);
}
