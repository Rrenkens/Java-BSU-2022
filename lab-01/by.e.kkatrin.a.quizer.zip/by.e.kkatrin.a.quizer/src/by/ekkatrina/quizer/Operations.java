package by.ekkatrina.quizer;

public enum Operations {
    PLUS,
    MINUS,
    TIMES,
    DIVIDED
}
