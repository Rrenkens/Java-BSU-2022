package by.ekkatrina.quizer.tasks;

import by.ekkatrina.quizer.Result;
import by.ekkatrina.quizer.Task;

public class TextTask implements Task {

    private final String text;
    private final String answer;

    public TextTask (String text,  String answer) {
        this.text = text;
        this.answer = answer;
    }
    @Override
    public String getText() {
        return text;
    }

    @Override
    public Result validate(String userAnswer) {
        if (userAnswer.equals(answer)) {
            return Result.OK;
        } else {
            return Result.WRONG;
        }
    }

    @Override
    public boolean isNumber(String answer) {
        return false;
    }
}
