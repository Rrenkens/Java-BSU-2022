package by.ekkatrina.quizer.tasks;

import by.ekkatrina.quizer.Result;
import by.ekkatrina.quizer.Task;

import java.util.InputMismatchException;

public class ExpressionTask implements Task {
    private final double result;
    private final String task;


    public ExpressionTask(String task, double result) {
        this.task = task;
        this.result = result;
    }

    @Override
    public String getText() {
        return task ;
    }

    @Override
    public Result validate(String answer) throws InputMismatchException {
        if (isNumber(answer)) {
            Double newRes = Double.parseDouble(answer);
            if (newRes.equals(result)) {
                return Result.OK;
            } else {
                return Result.WRONG;
            }
        } else {
            return  Result.INCORRECT_INPUT;
        }
    }

    @Override
    public boolean isNumber(String answer) throws NumberFormatException {
        try {
            Double.parseDouble(answer);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
