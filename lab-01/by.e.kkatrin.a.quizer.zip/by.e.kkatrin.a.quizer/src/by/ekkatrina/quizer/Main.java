package by.ekkatrina.quizer;

import by.ekkatrina.quizer.task_generators.EquationTaskGenerator;
import by.ekkatrina.quizer.task_generators.ExpressionTaskGenerator;
import by.ekkatrina.quizer.task_generators.GroupTaskGenerator;
import by.ekkatrina.quizer.task_generators.PoolTaskGenerator;
import by.ekkatrina.quizer.tasks.EquationTask;
import by.ekkatrina.quizer.tasks.ExpressionTask;
import by.ekkatrina.quizer.tasks.TextTask;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    static Map<String, Quiz> getQuizMap() {
        Map<String, Quiz> map = new HashMap<>();
        map.put("Razmyslovich", new Quiz(
                new ExpressionTaskGenerator(    //all operations
                        10,
                        15,
                        true,
                        true,
                        true,
                        true),
                 15));
        map.put("Radyno", new Quiz(               //sum and difference
                new ExpressionTaskGenerator(
                        20,
                        50,
                        true,
                        true,
                        false,
                        false),
                20));
        map.put("Riabyj", new Quiz(
                new EquationTaskGenerator(      //multiplication
                        10000,
                        10000000,
                        false,
                        false,
                        true,
                        false),
                5));
        map.put("Kastrica", new Quiz(           //sum
                new EquationTaskGenerator(
                        5,
                        60,
                        true,
                        false,
                        false,
                        false),
                10));
        map.put("Ugarina", new Quiz(
                new GroupTaskGenerator(new ExpressionTaskGenerator(
                        5, 10,
                        true, true, true, true),
                        new EquationTaskGenerator(12, 24,
                                true, true, true, true)),
                10));
        map.put("Sitnikova", new Quiz(
                new PoolTaskGenerator(false,
                        new ExpressionTask("9 + 5 = ?", 14),
                        new EquationTask("x + 14 = 10", -4),
                        new ExpressionTask("14 + 6 = ?", 20),
                        new TextTask("Если вы хоть чуть-чуть читали конспект, то экзамен будет для вас совсем ...",
                                "несложным")),
                4));
        map.put("GuessWho", new Quiz(
                new PoolTaskGenerator( false,
                        new TextTask("Кто лучше всех?", "Екатерина Новикова"),
                        new TextTask("Кто съедает всю еду?", "Алексей Ставер"),
                        new TextTask("Кто та самая?", "Валерия Мартынюк"),
                        new TextTask("Кто потерял кроссовки", "Алексей Боричевский"),
                        new TextTask("Кто бронза ай о ай?", "Андрей Костяной"),
                        new TextTask("Кто ставка?", "Ксения Ставицкая"),
                        new TextTask("Кто не дает открывать окно в 1011", "Альбина Борикова"),
                        new TextTask("Кто не дает открывать окно в 1014", "Ксения Ставицкая"),
                        new TextTask("Кто мини Размыслович?", "Руслан Парфенов")),
                9));
        
        return map;
    }
    public static void main(String[] args) {
        getQuizMap();
        Quiz currentQuiz;
        System.out.println("Enter test name, please!");
        Scanner in = new Scanner(System.in);
        String name = in.nextLine();
        while (!getQuizMap().containsKey(name)) {
            System.out.println("Try again!");
            name = in.nextLine();
        }
        System.out.println("Let Start, bro!!");
        currentQuiz = getQuizMap().get(name);
        Result check = Result.OK;
        while (!currentQuiz.isFinished()) {
            if (check != Result.INCORRECT_INPUT) {
                System.out.println(currentQuiz.nextTask().getText());
            }
            String answer = in.nextLine();
            check = currentQuiz.provideAnswer(answer);
        }
        System.out.println("Ваша отметка: " + currentQuiz.getMark());
    }


}