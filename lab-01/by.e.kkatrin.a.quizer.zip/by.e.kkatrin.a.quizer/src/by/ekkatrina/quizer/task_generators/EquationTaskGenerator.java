package by.ekkatrina.quizer.task_generators;

import by.ekkatrina.quizer.Operations;
import by.ekkatrina.quizer.TaskGenerator;
import by.ekkatrina.quizer.tasks.EquationTask;

import java.util.ArrayList;

public class EquationTaskGenerator implements TaskGenerator {
    private final int minNumber;
    private final int maxNumber;
    private final boolean generateSum;
    private final boolean generateDifference;
    private final boolean generateMultiplication;
    private final boolean generateDivision;

    public EquationTaskGenerator(
            int minNumber,
            int maxNumber,
            boolean generateSum,
            boolean generateDifference,
            boolean generateMultiplication,
            boolean generateDivision
    ) {
        this.minNumber = minNumber;
        this.maxNumber = maxNumber;
        this.generateSum = generateSum;
        this.generateDifference = generateDifference;
        this.generateMultiplication = generateMultiplication;
        this.generateDivision = generateDivision;
    }

    @Override
    public String getOperation(Operations operation) {
        if (operation.equals(Operations.PLUS)) {
            return "+";
        } else if (operation.equals(Operations.MINUS)) {
            return "-";
        } else if (operation.equals(Operations.TIMES)) {
            return "*";
        } else {
            return "/";
        }
    }

    @Override
    public EquationTask generate() {
        ArrayList<Operations> validOperations = new ArrayList<>(4);
        if (generateSum) {
            validOperations.add(Operations.PLUS);
        }
        if (generateDifference) {
            validOperations.add(Operations.MINUS);
        }
        if (generateMultiplication) {
            validOperations.add(Operations.TIMES);
        }
        if (generateDivision) {
            validOperations.add(Operations.DIVIDED);
        }
        int numberOperations = validOperations.size();

        int leftNumber = minNumber + (int) (Math.random() * (maxNumber - minNumber + 1));
        int result = minNumber + (int) (Math.random() * (maxNumber - minNumber + 1));
        Operations operation = validOperations.get((int) (Math.random() * numberOperations));
        double variable = 0;
        int varPlace = (int) (Math.random() * 2);
        String string;
        if (varPlace == 0) {
            string = "x " + getOperation(operation) + " " + leftNumber + " = " + result;
            if (operation.equals(Operations.PLUS)) {
                variable = result - leftNumber;
            } else if (operation.equals(Operations.MINUS)) {
                variable = result + leftNumber;
            } else if (operation.equals(Operations.TIMES)) {
                variable = (double) result / leftNumber;
            } else if (operation.equals(Operations.DIVIDED)) {
                variable = result * leftNumber;
            }
        } else {
            string = leftNumber + " " + getOperation(operation) + " x = " + result;
            if (operation.equals(Operations.PLUS)) {
                variable = result - leftNumber;
            } else if (operation.equals(Operations.MINUS)) {
                variable = leftNumber - result;
            } else if (operation.equals(Operations.TIMES)) {
                variable = (double) result / leftNumber;
            } else if (operation.equals(Operations.DIVIDED)) {
                variable = (double) leftNumber / result;
            }
        }
        return new EquationTask(string, variable);
    }
}

