package by.ekkatrina.quizer.task_generators;

import by.ekkatrina.quizer.Operations;
import by.ekkatrina.quizer.TaskGenerator;
import by.ekkatrina.quizer.tasks.ExpressionTask;

import java.util.ArrayList;

public class ExpressionTaskGenerator implements TaskGenerator {

    private final int minNumber;
    private final int maxNumber;
    private final boolean generateSum;
    private final boolean generateDifference;
    private final boolean generateMultiplication;
    private final boolean generateDivision;

    public ExpressionTaskGenerator(
            int minNumber,
            int maxNumber,
            boolean generateSum,
            boolean generateDifference,
            boolean generateMultiplication,
            boolean generateDivision
    ) {
        this.minNumber = minNumber;
        this.maxNumber = maxNumber;
        this.generateSum = generateSum;
        this.generateDifference = generateDifference;
        this.generateMultiplication = generateMultiplication;
        this.generateDivision = generateDivision;
    }

    @Override
    public String getOperation(Operations operation) {
        if (operation.equals(Operations.PLUS)) {
            return "+";
        } else if (operation.equals(Operations.MINUS)) {
            return "-";
        } else if (operation.equals(Operations.TIMES)) {
            return "*";
        } else {
            return "/";
        }
    }

    @Override
    public ExpressionTask generate() {
        ArrayList<Operations> validOperations = new ArrayList<>(4);
        if (generateSum) {
            validOperations.add(Operations.PLUS);
        }
        if (generateDifference) {
            validOperations.add(Operations.MINUS);
        }
        if (generateMultiplication) {
            validOperations.add(Operations.TIMES);
        }
        if (generateDivision) {
            validOperations.add(Operations.DIVIDED);
        }
        int numberOperations = validOperations.size();
        int firstNumber = minNumber +  (int) (Math.random() * (maxNumber - minNumber + 1));
        int secondNumber = minNumber +  (int) (Math.random() * (maxNumber - minNumber + 1));
        Operations operation = validOperations.get((int) (Math.random() * numberOperations));
        String string = firstNumber + " " + getOperation(operation) + " " + secondNumber + " =" + " ?";
        double result;
        if (operation.equals(Operations.PLUS)) {
            result = firstNumber + secondNumber;
        } else if (operation.equals(Operations.MINUS)) {
            result = firstNumber - secondNumber;
        } else if (operation.equals(Operations.TIMES)) {
            result = firstNumber * secondNumber;
        } else if (operation.equals(Operations.DIVIDED)) {
            result = (double) firstNumber / secondNumber;
        } else {
            result = 0;
        }
        return new ExpressionTask(string, result);
    }
}
