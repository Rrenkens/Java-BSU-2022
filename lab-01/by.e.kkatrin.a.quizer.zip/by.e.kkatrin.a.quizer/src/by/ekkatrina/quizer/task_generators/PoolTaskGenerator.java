package by.ekkatrina.quizer.task_generators;

import by.ekkatrina.quizer.Operations;
import by.ekkatrina.quizer.Task;
import by.ekkatrina.quizer.TaskGenerator;

import java.util.ArrayList;
import java.util.Collections;

public class PoolTaskGenerator implements TaskGenerator {
    private ArrayList<Task> tasks = new ArrayList<>();
    private boolean allowDuplicate;

    public PoolTaskGenerator (boolean allowDuplicate, Task ... tasks) {
            this.allowDuplicate = allowDuplicate;
            for (Task task : tasks) {
                if (!this.tasks.contains(task)) {
                    this.tasks.add(task);
                }
            }
    }

    public PoolTaskGenerator (boolean allowDuplicate, ArrayList<Task> tasks) {
        this.allowDuplicate = allowDuplicate;
        for (Task task : tasks) {
            if (!this.tasks.contains(task)) {
                this.tasks.add(task);
            }
        }
    }

    @Override
    public Task generate()  {
        int number = (int) (Math.random() * tasks.size());
        Task currentTask = tasks.get(number);
        if (!allowDuplicate) {
            tasks.remove(number);
        }
        return currentTask;
    }

    @Override
    public String getOperation(Operations operation) {
        return null;
    }
}
