package by.ekkatrina.quizer.task_generators;

import by.ekkatrina.quizer.Operations;
import by.ekkatrina.quizer.Task;
import by.ekkatrina.quizer.TaskGenerator;

import java.util.ArrayList;
import java.util.Collections;

public class GroupTaskGenerator implements TaskGenerator {
    private ArrayList<TaskGenerator> generators = new ArrayList<>();
    public GroupTaskGenerator(TaskGenerator ... generators) {
        Collections.addAll(this.generators, generators);
    }

    public GroupTaskGenerator(ArrayList<TaskGenerator> generators) {
        this.generators = generators;
    }
    @Override
    public Task generate() {
        int method = (int) (Math.random() * generators.size());
        return generators.get(method).generate();
    }

    @Override
    public String getOperation(Operations operation) {
        return null;
    }
}