package by.ekkatrina.quizer;
public interface TaskGenerator {
    Task generate();
    public String getOperation(Operations operation);
}
