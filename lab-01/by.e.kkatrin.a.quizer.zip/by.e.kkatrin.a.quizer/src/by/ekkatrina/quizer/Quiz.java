package by.ekkatrina.quizer;


public class Quiz {
    private final TaskGenerator generator;
    private final int taskCount;
    private int taskLeft;

    private Task currentTask = null;
    private int rightAnswers = 0 ;
    private int wrongAnswers = 0;
    private int incorrectInputAnswers = 0;


    Quiz(TaskGenerator generator, int taskCount) {
        this.generator = generator;
        this.taskCount = taskCount;
        this.taskLeft = taskCount;
    }


    Task nextTask() {
        if (!isFinished())  {
            taskLeft--;
            currentTask = generator.generate();
            return currentTask;
        }
        return null;
    }

    Result provideAnswer(String answer) {
        if (currentTask.validate(answer).equals(Result.OK)) {
            rightAnswers++;
            System.out.println("Great!");
            return Result.OK;
        } else if (currentTask.validate(answer).equals(Result.WRONG)) {
            wrongAnswers++;
            System.out.println("Ooops!");
            return Result.WRONG;
        } else {
            System.out.println("Incorrect input!!!!!");
            incorrectInputAnswers++;
            return Result.INCORRECT_INPUT;
        }
    }

    boolean isFinished() {
        return taskLeft == 0;
    }

    int getCorrectAnswerNumber() {
        return rightAnswers;
    }

//    int getWrongAnswerNumber() {
//        return wrongAnswers;
//    }

//    int getIncorrectInputNumber() {
//        return incorrectInputAnswers;
//    }

    int getMark() {
        if (taskCount != 0) {
            return (getCorrectAnswerNumber() * 10 / taskCount);
        }
        return 0;
    }
}
