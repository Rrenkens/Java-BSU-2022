package by.ekkatrina.quizer;

public enum Result {
        OK,
        WRONG,
        INCORRECT_INPUT
    }

